import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import request from 'supertest';

const tempDir=fs.mkdtempSync(path.join(os.tmpdir(),'pagevault-test-'));
process.env.DB_PATH=path.join(tempDir,'test.sqlite');
process.env.NODE_ENV='test';
let app;
before(async()=>{({default:app}=await import('../index.js'));});
after(()=>{try{fs.rmSync(tempDir,{recursive:true,force:true});}catch{}});

async function register(name,email){
 const res=await request(app).post('/api/auth/register').send({name,email,password:'secure-pass-123'});
 assert.equal(res.status,201,res.body.error);
 return res.body.token;
}
test('registers accounts and rejects duplicate email addresses',async()=>{
 const token=await register('Lender Student','lender@example.test');
 assert.ok(token);
 const duplicate=await request(app).post('/api/auth/register').send({name:'Another Name',email:'lender@example.test',password:'secure-pass-123'});
 assert.equal(duplicate.status,409);
});
test('protects API routes and validates book inputs',async()=>{
 const unauth=await request(app).get('/api/books');
 assert.equal(unauth.status,401);
 const token=await register('Book Owner','owner@example.test');
 const invalid=await request(app).post('/api/books').set('Authorization',`Bearer ${token}`).send({title:'',author:'A',courseCode:'CS1',department:'CSE',condition:'Good'});
 assert.equal(invalid.status,400);
});
test('supports the borrow workflow with a 14-day due date',async()=>{
 const lenderToken=await register('Owner','owner2@example.test');
 const borrowerToken=await register('Borrower','borrower@example.test');
 const listing=await request(app).post('/api/books').set('Authorization',`Bearer ${lenderToken}`).send({
  title:'Test Algorithms',author:'A. Author',edition:'2nd',courseCode:'CS401',department:'Computer Science',condition:'Good'
 });
 assert.equal(listing.status,201);
 const bookId=listing.body.id;
 const ownRequest=await request(app).post('/api/requests').set('Authorization',`Bearer ${lenderToken}`).send({bookId});
 assert.equal(ownRequest.status,400);
 const borrow=await request(app).post('/api/requests').set('Authorization',`Bearer ${borrowerToken}`).send({bookId});
 assert.equal(borrow.status,201);
 const approve=await request(app).patch(`/api/requests/${borrow.body.id}`).set('Authorization',`Bearer ${lenderToken}`).send({action:'approve'});
 assert.equal(approve.status,200);
 const days=(new Date(approve.body.dueDate)-Date.now())/86400000;
 assert.ok(days>13.9 && days<=14.01,`expected 14-day deadline, got ${days}`);
 const returned=await request(app).patch(`/api/requests/${borrow.body.id}`).set('Authorization',`Bearer ${borrowerToken}`).send({action:'returned'});
 assert.equal(returned.status,200);
 assert.equal(returned.body.status,'Returned');
});
